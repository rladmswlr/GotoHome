﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Gamemanager : MonoBehaviour
{
    int coinCount = 0;
    public Text coinText;
    private AudioSource m_audio;
    public AudioClip BGMSound;

    void GetCoin()
    {
        coinCount++;
        coinText.text = "획득한 Coin : " + coinCount;
        //Debug.Log("Coin: " + coinCount);
    }


    // Start is called before the first frame update
    void Start()
    {
        // GameObject에 <AudioSource> component 추가.
        this.m_audio = this.gameObject.AddComponent<AudioSource>();
        // 반복 재생을 않도록 설정.
        this.m_audio.loop = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
        }

        this.m_audio.clip = this.BGMSound;
        this.m_audio.volume = 0.1f;
        if (this.m_audio.isPlaying == false) // replay 중이 아니면
        {
            this.m_audio.volume = 0.1f;
            this.m_audio.Play(); // audio clip 음원을 재생.
        }
    }
}
