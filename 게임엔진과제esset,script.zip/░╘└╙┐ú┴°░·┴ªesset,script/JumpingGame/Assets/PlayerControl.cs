﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerControl : MonoBehaviour
{
    private AudioSource p_audio;
    public AudioClip jumpSound1; // jump 음원
    public AudioClip attackSound;
    public AudioClip GoalSound;
    public float movespeed = 10.0f;
    public float jumpPower = 26.5f;
    public float jumpPower2 = 22.0f;
    [SerializeField] private Animator m_animator;
    private bool m_isGrounded;


    int jumpCount = 0;

    Rigidbody rigdbody;
    bool isJumping;

    CharacterController characterController;
    // Start is called before the first frame update
    void Start()
    {
        // GameObject에 <AudioSource> component 추가.
        this.p_audio = this.gameObject.AddComponent<AudioSource>();
        // 반복 재생을 않도록 설정.
        this.p_audio.loop = false;

        m_isGrounded = true;
        rigdbody = GetComponent<Rigidbody>();
        characterController = GetComponent<CharacterController>();
    }

    // Update is called once per frame
    void Update()
    {
        m_animator.SetBool("Grounded", m_isGrounded);

        transform.Translate(movespeed * Vector3.forward * Time.deltaTime, Space.World);

        if (Input.GetButtonDown("Jump"))
            Jump();

    }

    void Jump()
    {
        //if (!isJumping)
        //    return;
        //rigdbody.AddForce(Vector3.up * jumpPower,ForceMode.Impulse);

        //isJumping = false;

        if(jumpCount == 0)
        {
            m_animator.SetTrigger("Jump");
            this.p_audio.clip = this.jumpSound1;
            this.p_audio.volume = 0.5f;
            this.p_audio.Play(); // audio clip에 들어있는 음원을 재생.
            jumpCount++;
            gameObject.GetComponent<Rigidbody>().velocity = new Vector3(0, jumpPower, 0);
        }

        else if(jumpCount == 1)
        {
            m_animator.SetTrigger("Jump");
            this.p_audio.clip = this.jumpSound1;
            this.p_audio.volume = 0.5f;
            this.p_audio.Play(); // audio clip에 들어있는 음원을 재생.
            jumpCount++;
            gameObject.GetComponent<Rigidbody>().velocity = new Vector3(0, jumpPower2, 0);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag.CompareTo("Coin") == 0)
        {
            GameObject.Find("Gamemanager").SendMessage("GetCoin");
            other.gameObject.SetActive(false);
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.tag.CompareTo("Ground") == 0)
        {
            m_isGrounded = true;
            jumpCount = 0;
        }

        if (collision.gameObject.tag.CompareTo("hurdle") == 0)
        {
            this.p_audio.clip = this.attackSound;
            this.p_audio.volume = 0.5f;
            this.p_audio.Play(); // audio clip에 들어있는 음원을 재생.
            GameObject.Find("Canvas2").transform.Find("GameOverPanel").gameObject.SetActive(true);
            Time.timeScale = 0;
        }

        if (collision.gameObject.tag.CompareTo("Water") == 0)
        {
            this.p_audio.clip = this.attackSound;
            this.p_audio.volume = 0.5f;
            this.p_audio.Play(); // audio clip에 들어있는 음원을 재생.
            GameObject.Find("Canvas2").transform.Find("GameOverPanel").gameObject.SetActive(true);
            Time.timeScale = 0;
        }
        
        if (collision.gameObject.tag.CompareTo("Ball") == 0)
        {
            this.p_audio.clip = this.attackSound;
            this.p_audio.volume = 0.5f;
            this.p_audio.Play(); // audio clip에 들어있는 음원을 재생.
            GameObject.Find("Canvas2").transform.Find("GameOverPanel").gameObject.SetActive(true);
            Time.timeScale = 0;
        }

        if (collision.gameObject.tag.CompareTo("FinishLine") == 0)
        {
            this.p_audio.clip = this.GoalSound;
            this.p_audio.Play(); // audio clip에 들어있는 음원을 재생.
        }
    }

    private void OnCollisionExit(Collision collision)
    {
        if (collision.gameObject.tag.CompareTo("Ground") == 0)
        {
            m_isGrounded = false;
        }
    }
}
