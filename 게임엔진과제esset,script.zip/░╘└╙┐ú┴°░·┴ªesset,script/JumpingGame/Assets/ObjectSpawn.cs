﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectSpawn : MonoBehaviour
{
    public GameObject prefab = null;

    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(SpawnRepeat());
    }

    private IEnumerator SpawnRepeat()
    {
        int randtime = (int)Random.Range(2, 4);
        while (true)
        {
            yield return new WaitForSeconds(randtime);
            SpawnEnemy();
            randtime = (int)Random.Range(4, 8);
        }
    }

    void SpawnEnemy()
    {
        // prefab변수에서 만들어진 GameObject를 가져옴.
        GameObject go = GameObject.Instantiate(this.prefab) as GameObject;
        // 가져온 GameObject의 설정을 변경.
        go.transform.position = new Vector3(0.0f, Random.Range(1.0f, 6.0f), 493.0f);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
